import React from 'react'

const Missing = () => {
  return (
    <div>Can't find page 404 ...</div>
  )
}

export default Missing