import React from 'react'

const SelectedBooks = () => {
  return (
    <div>SelectedBooks</div>
  )
}

export default SelectedBooks