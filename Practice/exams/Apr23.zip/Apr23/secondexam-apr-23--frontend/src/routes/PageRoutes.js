import React from 'react'
import { Routes , Route} from 'react-router-dom';
import Homepage from '../pages/Homepage';
import Books from '../components/Books'
import BookDetails from '../components/BookDetails';
import AddBook from '../components/AddBook';
import SelectedBooks from '../components/SelectedBooks';
import EditBook from '../components/EditBook';



const PageRoutes = () => {
    return (
        <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/books" element={<Books />} />
            <Route path="/books/:isbn" element={<BookDetails />} />
            <Route path="/add-book" element={<AddBook />} />
            <Route path="/selected-books" element={<SelectedBooks />} />
            <Route path="/books/:isbn/edit" element={<EditBook />} />

            {/* Complete routes here... */}
         
        </Routes>
    )
}

export default PageRoutes