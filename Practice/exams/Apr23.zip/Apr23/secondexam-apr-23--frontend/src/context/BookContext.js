import React, { createContext, useState } from 'react';

export const BookContext = createContext();

export const BookProvider = ({ children }) => {
  const [selectedBooks, setSelectedBooks] = useState([]);

  const addSelectedBook = (book) => {
    setSelectedBooks((prevSelectedBooks) => [...prevSelectedBooks, book]);
  };

  const removeSelectedBook = (isbn) => {
    setSelectedBooks((prevSelectedBooks) =>
      prevSelectedBooks.filter((book) => book.isbn !== isbn)
    );
  };

  return (
    <BookContext.Provider value={{ selectedBooks, addSelectedBook, removeSelectedBook }}>
      {children}
    </BookContext.Provider>
  );
};
