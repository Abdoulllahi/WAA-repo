import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const EditBook = () => {
  const { isbn } = useParams();
  const navigate = useNavigate();

  const [book, setBook] = useState(null);
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');

  useEffect(() => {
    fetchBookDetails();
  }, []);

  const fetchBookDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/v1/books/${isbn}`);
      setBook(response.data);
      setTitle(response.data.title);
      setPrice(response.data.price);
    } catch (error) {
      console.error('Error fetching book details', error);
    }
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handlePriceChange = (e) => {
    setPrice(e.target.value);
  };

  const handleUpdate = async () => {
    try {
      await axios.put(`http://localhost:8080/api/v1/books/${isbn}`, { title, price });
      navigate(`/books/${isbn}`);
    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  const handleCancel = () => {
    navigate(`/books/${isbn}`);
  };

  if (!book) {
    return <div>Loading book details...</div>;
  }

  return (
    <div>
      <h2>Edit Book</h2>
      <div>
        <label htmlFor="title">Title:</label>
        <input type="text" id="title" value={title} onChange={handleTitleChange} />
      </div>
      <div>
        <label htmlFor="price">Price:</label>
        <input type="text" id="price" value={price} onChange={handlePriceChange} />
      </div>
      <button onClick={handleUpdate}>Update</button>
      <button onClick={handleCancel}>Cancel</button>
    </div>
  );
};

export default EditBook;
