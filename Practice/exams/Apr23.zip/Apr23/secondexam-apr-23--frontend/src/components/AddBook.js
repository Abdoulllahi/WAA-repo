/**
 * @ Author: Abdou Lahi DIOP
 * @ Create Time: 2023-06-16 18:06:08
 * @ Modified by: Abdou Lahi DIOP
 * @ Modified time: 2023-06-16 22:32:15
 * @ Description:
 */

import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useState } from "react";
import './NewProduct.css';

const AddBook = () => {
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [category, setCategory] = useState("");
    const [authors, setAuthors] = useState("");
    const navigate = useNavigate();

    const handleTitleChange = (event) => {
        setTitle(event.target.value);
    };

    const handlePriceChange = (event) => {
        setPrice(event.target.value);
    };

    const handleCategoryChange = (event) => {
        setCategory(event.target.value);
    };

    const handleAuthorsChange = (event) => {
        setAuthors(event.target.value);
    };

    const AddHandler = async (e) => {
        e.preventDefault();

        const book = {
            title,
            price: parseFloat(price),
            category: { name: category }, // Update to include the name property
            authors: authors.split(" ").map((name) => ({ name })),
        };

        try {
            await axios.post("http://localhost:8080/api/v1/books", book);

            navigate("/books");
        } catch (error) {
            console.error("Error adding book: ", error);
        }
    };

    const handleCancel = () => {
        navigate(-1);
    };

    return (
        <div className="NewProduct">
            <form onSubmit={AddHandler}>
                <h1>Add a Book</h1>

                <label>Title</label>
                <input
                    type="text"
                    label="title"
                    name="title"
                    value={title}
                    onChange={handleTitleChange}
                />

                <label>Price</label>
                <input
                    type="text"
                    label="price"
                    name="price"
                    value={price}
                    onChange={handlePriceChange}
                />

                <label>Category</label>
                <input
                    type="text"
                    label="category"
                    name="category"
                    value={category}
                    onChange={handleCategoryChange}
                />

                <label>Author/s</label>
                <input
                    type="text"
                    label="authors"
                    name="authors"
                    value={authors}
                    onChange={handleAuthorsChange}
                />
                <button>Add Book</button>

                <br />
                <br />
                <br />

                <div className="Spec">
                    <button onClick={handleCancel}>Cancel</button>
                </div>
            </form>
        </div>
    );
};

export default AddBook;
