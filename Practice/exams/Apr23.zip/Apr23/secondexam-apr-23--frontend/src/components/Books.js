/**
 * @ Author: Abdou Lahi DIOP
 * @ Create Time: 2023-06-16 18:16:56
 * @ Modified by: Abdou Lahi DIOP
 * @ Modified time: 2023-06-16 22:35:14
 * @ Description:
 */

import axios from "axios";
import { useEffect, useState, useRef } from "react"
import Book from "./Book";
import { Link, useNavigate } from "react-router-dom/dist";

const Books = () => {
    const [books, setBook] = useState(
        [
            { id: 1, title: "TEST", price: 100 },
            { id: 2, title: "TEST", price: 200 },

        ]
    );
    const catParam = useRef();
    const titleParam = useRef();
    const minParam = useRef();
    const maxParam = useRef()
    const navigate = useNavigate();

    useEffect(() => {
        fetchBooks();
    }, [])

    const handleFilterSubmit = (e) => {
        e.preventDefault();
        fetchBooks();
    };

    const fetchBooks = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/v1/books', {
                params: {
                    category: catParam.current.value,
                    titleParam: titleParam.current.value,
                    minPrice: minParam.current.value,
                    maxPrice: maxParam.current.value,
                }
            });
            setBook(response.data);
        } catch (error) {
            console.error("Error fetching books: error");
        }
    };

    return (

        <div className="Product">
            <div className="">
                <form onSubmit={handleFilterSubmit}>
                    <input type="text" placeholder="Category" ref={catParam} />
                    <input type="text" placeholder="Title" ref={titleParam} />
                    <input type="number" placeholder="Min Price" ref={minParam} />
                    <input type="number" placeholder="Max Price" ref={maxParam} />
                    <button type="submit">Filter</button>
                </form>
            </div>
            {books.map((book) => (
                <Link to={`${book.isbn}`}>
                    <Book
                        key={book.isbn}
                        isbn={book.isbn}
                        title={book.title}
                        price={book.price}
                    />
                </Link>
            ))}

            <div style={{ display: "block" }}>
                <div className="Spec" >
                    <button onClick={() => { navigate("/"); }}> Back</button>
                </div>
            </div>
        </div>
    )
}

export default Books;