import React, { useContext, useState } from 'react';
import { BookContext } from '../context/BookContext';

const SelectedBooks = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { selectedBooks, removeSelectedBook } = useContext(BookContext);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredBooks = selectedBooks.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <h2>Selected Books</h2>
      <input
        type="text"
        placeholder="Search by title"
        value={searchTerm}
        onChange={handleSearch}
      />
      {filteredBooks.length === 0 ? (
        <p>No Selected Book</p>
      ) : (
        <ul>
          {filteredBooks.map((book) => (
            <li key={book.isbn}>
              <span>Title: {book.title}</span>
              <span>ISBN: {book.isbn}</span>
              <button onClick={() => removeSelectedBook(book.isbn)}>Unselect</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SelectedBooks;
