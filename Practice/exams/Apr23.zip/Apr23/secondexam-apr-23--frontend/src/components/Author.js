import React from 'react';

const Author = ({ name }) => {
  return (
    <div>
      <p>{name}</p>
    </div>
  );
};

export default Author;
