import './BookDetails.css';
import axios from 'axios';
import { useEffect, useState, useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom/dist';
import { BookContext } from '../context/BookContext';
import Author from './Author';

const BookDetails = () => {
  const { isbn } = useParams();
  const [book, setBook] = useState(null);
  const navigate = useNavigate();
  const { selectedBooks, addSelectedBook } = useContext(BookContext);

  useEffect(() => {
    fetchBookDetails();
  });

  const fetchBookDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/v1/books/${isbn}`);
      setBook(response.data);
    } catch (error) {
      console.error('Error fetching book details', error);
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:8080/api/v1/books/${isbn}`);
      navigate('/books');
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  const handleSelect = () => {
    addSelectedBook(book);
  };

  const handleBack = () => {
    navigate(-1);
  };

  const handleEdit = () => {
    navigate(`/books/${isbn}/edit`);
  };

  if (!book) {
    return <div>Loading book details...</div>;
  }

  return (
    <div className="ProductDetail">
      <h2>Book Details</h2>
      <p>Title: {book.title}</p>
          <p>ISBN: {book.isbn}</p>
          <div><p>Authors: </p>{book.authors.map((author) => (
        <Author key={author.id} name={author.name} />
      ))}</div>
      <p>Price: {book.price}$</p>
      <button onClick={handleDelete}>Delete</button>
      <button onClick={handleSelect}>
        {selectedBooks.some((selectedBook) => selectedBook.isbn === book.isbn)
          ? 'Unselect'
          : 'Select'}
      </button>
      <button onClick={handleBack}>Back</button>
      <button onClick={handleEdit}>Edit</button>
    </div>
  );
};

export default BookDetails;
