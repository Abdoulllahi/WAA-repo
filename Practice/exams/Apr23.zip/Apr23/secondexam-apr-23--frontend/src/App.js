import React from 'react';
import PageRoutes from './routes/PageRoutes';
import { BookProvider } from './context/BookContext';

function App() {
  return (
    <div className="App">
      <BookProvider>
        <PageRoutes />
      </BookProvider>
    </div>
  );
}

export default App;
