import React from 'react'
import './Homepage.css'
import { Link } from 'react-router-dom/dist'

const Homepage = () => {
  return (
    <div>
        <h1>Homepage</h1>

<ul class="list">
    <li class="i-one"> <Link to={"/books"}>Books</Link></li>
    <li class="i-two"> <Link to={"/add-book"}>Add Books</Link></li>
    <li class="i-three"><Link to={"/selected-books"}>Selected Books</Link></li> {/*to define*/}
</ul>
    </div>
  )
}

export default Homepage