//package edu.miu.springdata1.service;
//
//
//import edu.miu.springdata1.entity.Book;
//
//import java.util.List;
//
//public interface BookService {
//
//    void save(Book book);
//
//    void delete(int id);
//
//    Book getById(int id);
//
//    List<Book> getAll();
//
//    ProductSimpleDto findDto(int id);
//
//
//}
