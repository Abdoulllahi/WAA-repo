package edu.miu.allinone.dto.output;

import lombok.Data;

@Data
public class CommentDto {

    long id;
    String name;

}
