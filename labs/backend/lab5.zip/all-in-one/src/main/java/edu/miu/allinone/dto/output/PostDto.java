package edu.miu.allinone.dto.output;

import lombok.Data;

@Data
public class PostDto {

    long id;
    String title;
    String content;
    String author;
}
