package edu.miu.allinone.service;

import edu.miu.allinone.entity.Comment;

public interface CommentService {
    void save(Comment comment);
}
