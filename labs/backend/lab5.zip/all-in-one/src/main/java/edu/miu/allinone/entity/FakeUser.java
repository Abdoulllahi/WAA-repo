package edu.miu.allinone.entity;

public class FakeUser {

    public static final String USERNAME = "fakeUser";
}
