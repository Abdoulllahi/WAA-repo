package edu.miu.allinone.service;

import edu.miu.allinone.entity.Logger;

public interface LoggerService {
    void saveLogger(Logger logger);
}
